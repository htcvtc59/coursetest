$(function() {

  $('#exampleAccordion').metisMenu();

  $('#menu2').metisMenu({
    toggle: false
  });

  $('#menu3').metisMenu();

});
